import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class ClickMeButton 
{

	public static void main(String[] args) 
	{
		JFrame myFrame = new JFrame("Click me v1.0");
		myFrame.setSize(400, 200);
		myFrame.setLocation(600,400);
		myFrame.setLayout(new FlowLayout());
		
		
		JButton myButton = new JButton("Click me");
		myFrame.add(myButton);

		JLabel mylabel = new JLabel("Count = 0 ");
		myFrame.add(mylabel);
		
		MyListener myListener = new MyListener(mylabel);
		myButton.addActionListener(myListener);
		
		myFrame.setVisible(true);
	}

}
