import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.Arrays;
import java.util.Random;

import javax.swing.Box;
import javax.swing.JFrame;
import javax.swing.JFrame;

public class MemoryGameEvanRonald 
{
	static long startTime = 0;

	public static void main(String[] args) 
	{
		JFrame myFrame = new JFrame("Memory Game v1.0");
		myFrame.setSize(800, 800);
		myFrame.setLocation(600,200);
		myFrame.setLayout(new GridLayout(4,4));
		/*
		1. Employ the shuffle code to layout cards randomly - DONE
		2. Use a for loop to setup all the cards automatically - DONE
		3. As each card is being laid out make sure you have a handler connected to that card - DONE
		4. Flip - with a delay of half a second - DONE 
		5. If two cards with same image then stay fliped - ???
		6. If all cards are flipped then show time taken for you to remember all cards - show difference in time
		*/
		int [] positions = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
		shuffle(positions);
		
		for(int i=0; i<16; i++)
		{
			Card temp = new Card(myFrame, "C:\\Java\\Day 1\\images\\" + (positions[i] % 8 + 1) + ".gif", (i+1));
			CardListener cardListener = new CardListener(temp);
			temp.addActionListener(cardListener); 
		}

		myFrame.setVisible(true);
		// Start a Timer()
		 startTime= System.currentTimeMillis();
		
	}

	private static void shuffle(int[] positions) 
	{
		Random rand = new Random();
		
		for (int i=0; i<16; i++)
		{
		int randomIndexToSwap = rand.nextInt(positions.length);
		int temp = positions[randomIndexToSwap];
		positions[randomIndexToSwap] = positions[i];
		positions[i] = temp;
		}
		System.out.println(Arrays.toString(positions));
	}

}
