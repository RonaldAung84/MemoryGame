
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class ButtonListener2 implements ActionListener
{
	JLabel myText;
	public ButtonListener2(JLabel fileNameDisplay)
	{
		myText = fileNameDisplay;
	}
	public void actionPerformed(ActionEvent arg0)
	{
		String filePath = "C:\\Java\\Day 1\\src\\";
		String fileName = JOptionPane.showInputDialog(this, "what is your blog name?");
		File myFile = new File(filePath + fileName);
		myText.setText(filePath + fileName);
		try {
			PrintWriter pw = new PrintWriter(myFile);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}
