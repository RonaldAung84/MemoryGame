import javax.swing.JButton;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JFrame;

public class Card extends JButton
{
	private String frontImage;
	private static int lastClickedPosition = 0 ;
	private static String lastCardImage = "";
	private String backImage = "C:/Java/Day 1/images/Back.gif";
	private JFrame jf;
	private int positions;
	private static int matchedCounter = 0;
	private static Card lastCardClicked; 
	// Constructor
	Card(JFrame mat, String fn, int pos)
	{
		jf = mat;
		positions = pos;
		frontImage = fn;
		Icon icon = new ImageIcon(backImage);
		this.setIcon(icon);
		mat.add(this);
	}
	
	public int getPosition()
	{
		return positions;
	}
	public void flipImage()
	{
		Icon icon1 = new ImageIcon(frontImage);
		this.setIcon((icon1));
		jf.update(jf.getGraphics());
	}
	public void flip(int newPos)
	{ 
		Icon icon1 = new ImageIcon(frontImage);
		this.setIcon((icon1));
		jf.update(jf.getGraphics());
		
		// if images are the same do not flip
		System.out.println("old Postition" + lastClickedPosition);
		System.out.println("New Postition" + newPos);
		
		if (lastCardImage.equals(frontImage) && lastClickedPosition != newPos)
		{
			System.out.println("MATCHED");
			lastCardClicked.flipImage();
			matchedCounter++;
		}
		else  //if image does not match then flip to back image
		{	
			try 
			{
				Thread.sleep(500);
			}  
			catch (InterruptedException e) 
			{
				e.printStackTrace();
			}
			Icon icon2 = new ImageIcon(backImage);
			this.setIcon(icon2);
		}
		lastCardImage = frontImage;
		lastClickedPosition = newPos;
		lastCardClicked = this;
		
		if (matchedCounter >= 8)
		{
			long endTime= System.currentTimeMillis();

			long elapsedTime = (endTime - MemoryGameEvanRonald.startTime) / 1000;
			JOptionPane.showMessageDialog(null, "YOU WON :) It took you " + elapsedTime + " seconds!");
		}
	}
}
