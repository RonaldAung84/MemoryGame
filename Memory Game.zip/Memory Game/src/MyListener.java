

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;

public class MyListener implements ActionListener
{
	private int count = 0;
	private JLabel label;
	
	MyListener(JLabel lb)
	{
		this.label = lb;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		count++;
		label.setText("Count = " + count);
		
	}
}
