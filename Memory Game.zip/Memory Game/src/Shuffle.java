import java.util.Random;
import java.util.Arrays;
public class Shuffle 
{

	public static void main(String[] args) 
	{
		int [] positions = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
		
		Random rand = new Random();
		
		for (int i=0; i<16; i++)
			{
			int randomIndexToSwap = rand.nextInt(positions.length);
			int temp = positions[randomIndexToSwap];
			positions[randomIndexToSwap] = positions[i];
			positions[i] = temp;
			}
		System.out.println(Arrays.toString(positions));
	}

}
