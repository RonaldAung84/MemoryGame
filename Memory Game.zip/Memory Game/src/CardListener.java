import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CardListener implements ActionListener
{
	private int count = 0;
	private Card myCard;
	private static int lastPos;
	
	CardListener(Card temp)
	{
		myCard = temp;
		
	}
	public void actionPerformed(ActionEvent e)
	{
		System.out.println("Clicked Card at position " + myCard.getPosition());
		myCard.flip(myCard.getPosition());
	}

}
                  